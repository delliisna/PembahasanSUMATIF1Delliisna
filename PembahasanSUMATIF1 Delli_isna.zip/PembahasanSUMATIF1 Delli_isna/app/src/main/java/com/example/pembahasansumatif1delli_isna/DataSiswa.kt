package com.example.pembahasansumatif1delli_isna

class DataSiswa (val gambar : Int,val nama : String)