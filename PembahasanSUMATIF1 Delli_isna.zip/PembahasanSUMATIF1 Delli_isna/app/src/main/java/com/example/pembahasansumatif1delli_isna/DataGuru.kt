package com.example.pembahasansumatif1delli_isna

class DataGuru (val gambar : Int,val nama : String)