package com.example.pembahasansumatif1delli_isna

 data class DataBuku(val gambar : Int,val nama : String)



